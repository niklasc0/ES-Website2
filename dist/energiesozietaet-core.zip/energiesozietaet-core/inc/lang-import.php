<?php
/**
 * Einspielen der Kundenübersetzungen (EN) aus data/translations-en.json.
 *
 * Die JSON-Datei wird aus der ausgefüllten Übersetzungsvorlage (XLSX)
 * generiert und enthält Zeilen { sheet, ref, en } bzw. für URL-Kürzel
 * { sheet, typ, de, en }. Referenzformate:
 *   live:<seiten-slug>:<widget-id>:<feld>  → Elementor-Text der EN-Seitenkopie
 *   einzelleistung|team|karriere.<slug>.<Feldlabel> → CPT-Meta (_en)
 *   settings.<Bereich>.<key>               → Options-Feld {key}_en
 *
 * @package Energiesozietaet_Core
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class ES_Lang_Import {

	/** Feldlabel (Vorlage) => Meta-Key-Logik je CPT-Blatt. */
	const FIELD_MAP = array(
		'einzelleistung' => array(
			'Titel' => 'es_title_en', 'Untertitel' => 'es_subtitle_en', 'Beschreibung' => 'content',
			// "Schwerpunkte unserer Beratung" ist das aktuelle Label; "Vorteile"
			// und "Kernpunkte" bleiben für bereits verschickte
			// Übersetzungsdateien gültig (gleiches Zielfeld).
			'Schwerpunkte unserer Beratung' => 'lines:es_bullets_en',
			'Vorteile' => 'lines:es_bullets_en', 'Kernpunkte' => 'lines:es_bullets_en',
			'Abschluss-Absatz' => 'es_closing_en',
		),
		'team' => array(
			'Rolle/Position' => 'es_role_en', 'Kurzvita' => 'content', 'Erweiterte Vita' => 'es_more_bio_en',
			'Schwerpunkte' => 'lines:es_focus_areas_en', 'Werdegang' => 'career:es_career_en',
		),
		'karriere' => array(
			'Titel' => 'es_title_en', 'Rollen-Kürzel' => 'es_department_en', 'Über die Rolle' => 'content',
			'Aufgaben' => 'lines:es_tasks_en', 'Profil' => 'lines:es_profile_en', 'Wir bieten' => 'lines:es_offer_en',
			'Anstellungsart' => 'es_employment_type_en',
		),
		'news' => array(
			'Titel' => 'es_title_en', 'Beitragstext' => 'content', 'Teaser' => 'es_excerpt_en',
		),
		'veranstaltung' => array(
			'Titel' => 'es_title_en', 'Beschreibung' => 'content', 'Ort' => 'es_location_en', 'Art' => 'es_kind_en',
		),
		'publikation' => array(
			'Titel' => 'es_title_en', 'Beschreibung' => 'content', 'Kategorie' => 'es_cat_en',
		),
	);

	const CPT_OF_SHEET = array(
		'einzelleistung' => 'es_einzelleistung', 'team' => 'es_team', 'karriere' => 'es_karriere',
		'news' => 'es_news', 'veranstaltung' => 'es_veranstaltung', 'publikation' => 'es_publikation',
	);

	/** URL-Kürzel-Typen (Vorlage) => Post-Type. */
	const URL_TYPES = array(
		'Einzelleistung' => 'es_einzelleistung', 'Stellenangebot' => 'es_karriere',
		'News-Artikel' => 'es_news', 'Veranstaltung' => 'es_veranstaltung', 'Publikation' => 'es_publikation',
	);

	public static function apply_file() {
		$file = ESC_DIR . 'data/translations-en.json';
		if ( ! file_exists( $file ) ) { return new WP_Error( 'no_file', 'data/translations-en.json nicht gefunden.' ); }
		$rows = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $rows ) ) { return new WP_Error( 'bad_file', 'translations-en.json fehlerhaft.' ); }
		return self::apply_rows( $rows );
	}

	/** Übersetzungszeilen ({ref, en} bzw. {typ, de, en}) anwenden. */
	public static function apply_rows( $rows ) {
		$stats = array( 'pages' => 0, 'cpt' => 0, 'settings' => 0, 'slugs' => 0, 'skipped' => array() );
		$page_data = array(); // de_slug => decoded elementor array der EN-Kopie (gesammelt, einmal speichern)

		foreach ( $rows as $r ) {
			$en = isset( $r['en'] ) ? trim( (string) $r['en'] ) : '';
			if ( '' === $en ) { continue; }
			$ref = isset( $r['ref'] ) ? (string) $r['ref'] : '';

			if ( 0 === strpos( $ref, 'live:' ) ) {
				list( , $slug, $wid, $field ) = array_pad( explode( ':', $ref, 4 ), 4, '' );
				if ( ! isset( $page_data[ $slug ] ) ) {
					$en_id = self::en_copy_id( $slug );
					if ( ! $en_id ) {
						// Neue Seite ohne EN-Kopie: Kopie automatisch anlegen
						ES_Lang::create_page_copies();
						$en_id = self::en_copy_id( $slug );
					}
					if ( ! $en_id ) { $stats['skipped'][] = $ref . ' (keine EN-Kopie)'; continue; }
					$page_data[ $slug ] = array( 'id' => $en_id, 'data' => json_decode( (string) get_post_meta( $en_id, '_elementor_data', true ), true ), 'hits' => 0 );
				}
				if ( ! is_array( $page_data[ $slug ]['data'] ) ) { $stats['skipped'][] = $ref . ' (keine Elementor-Daten)'; continue; }
				if ( self::set_widget_text( $page_data[ $slug ]['data'], $wid, $field, $en ) ) {
					$page_data[ $slug ]['hits']++;
					$stats['pages']++;
				} else {
					$stats['skipped'][] = $ref . ' (Widget nicht gefunden)';
				}
				continue;
			}

			if ( 0 === strpos( $ref, 'settings.' ) ) {
				list( , $area, $key ) = array_pad( explode( '.', $ref, 3 ), 3, '' );
				$opt = ( false !== stripos( $area, 'footer' ) ) ? 'esc_footer' : 'esc_karriere';
				$opts = (array) get_option( $opt, array() );
				$opts[ $key . '_en' ] = $en;
				update_option( $opt, $opts );
				$stats['settings']++;
				continue;
			}

			// CPT-Referenz: <blatt>.<slug>.<Feldlabel>
			if ( preg_match( '/^(einzelleistung|team|karriere|news|veranstaltung|publikation)\.([^.]+)\.(.+)$/u', $ref, $m ) ) {
				$post = get_page_by_path( $m[2], OBJECT, self::CPT_OF_SHEET[ $m[1] ] );
				if ( ! $post ) { $stats['skipped'][] = $ref; continue; }
				// Aufklapp-Rubriken der Einzelleistungen: "Rubrik <n> Titel|Inhalt"
				if ( 'einzelleistung' === $m[1] && preg_match( '/^Rubrik (\d+) (Titel|Inhalt)$/u', $m[3], $rm ) ) {
					$idx = (int) $rm[1] - 1;
					$arr = get_post_meta( $post->ID, 'es_accordion_en', true );
					if ( ! is_array( $arr ) ) { $arr = array(); }
					// Gerüst aus der DE-Fassung, damit Anzahl und Reihenfolge stimmen
					$de_acc = get_post_meta( $post->ID, 'es_accordion', true );
					if ( is_array( $de_acc ) ) {
						foreach ( array_keys( array_values( $de_acc ) ) as $i ) {
							if ( ! isset( $arr[ $i ] ) ) { $arr[ $i ] = array( 'title' => '', 'content' => '' ); }
						}
					}
					if ( ! isset( $arr[ $idx ] ) ) { $arr[ $idx ] = array( 'title' => '', 'content' => '' ); }
					if ( 'Titel' === $rm[2] ) { $arr[ $idx ]['title'] = sanitize_text_field( $en ); }
					else { $arr[ $idx ]['content'] = wp_kses_post( ESC_MetaBoxes::acc_text_to_html( $en ) ); }
					ksort( $arr );
					update_post_meta( $post->ID, 'es_accordion_en', array_values( $arr ) );
					$stats['cpt']++;
					continue;
				}
				$map = self::FIELD_MAP[ $m[1] ];
				if ( ! isset( $map[ $m[3] ] ) ) { $stats['skipped'][] = $ref; continue; }
				self::set_cpt_field( $post->ID, $map[ $m[3] ], $en );
				$stats['cpt']++;
				continue;
			}

			if ( 0 === strpos( $ref, 'url:' ) ) {
				list( , $typ, $de ) = array_pad( explode( ':', $ref, 3 ), 3, '' );
				$r = array( 'typ' => $typ, 'de' => $de, 'en' => $en );
			}
			// URL-Kürzel (typ/de/en) – nur zählen/schreiben, wenn sich der Wert
			// tatsächlich ändert (der Export befüllt die EN-Spalte vor, sonst
			// meldet jeder Upload alle Kürzel als "eingespielt")
			if ( isset( $r['typ'], $r['de'] ) ) {
				$en_slug = sanitize_title( $en );
				if ( 'Seite' === $r['typ'] ) {
					$en_id = self::en_copy_id( (string) $r['de'] );
					if ( $en_id && $en_slug !== (string) get_post_meta( $en_id, 'es_public_slug', true ) ) {
						update_post_meta( $en_id, 'es_public_slug', $en_slug );
						$stats['slugs']++;
					}
				} elseif ( isset( self::URL_TYPES[ $r['typ'] ] ) ) {
					$pt = self::URL_TYPES[ $r['typ'] ];
					$post = get_page_by_path( (string) $r['de'], OBJECT, $pt );
					if ( $post && $en_slug !== (string) get_post_meta( $post->ID, 'es_slug_en', true ) ) {
						update_post_meta( $post->ID, 'es_slug_en', $en_slug );
						$stats['slugs']++;
					}
				} else {
					$stats['skipped'][] = 'URL-Basis ' . $r['de'] . ' (im Code zu ändern)';
				}
				continue;
			}

			$stats['skipped'][] = $ref ? $ref : wp_json_encode( $r );
		}

		// Geänderte Seitenkopien speichern + als übersetzt markieren
		foreach ( $page_data as $slug => $pd ) {
			if ( $pd['hits'] > 0 ) {
				update_post_meta( $pd['id'], '_elementor_data', wp_slash( wp_json_encode( $pd['data'], JSON_UNESCAPED_UNICODE ) ) );
				update_post_meta( $pd['id'], 'es_translated', 1 );
			}
		}
		if ( class_exists( '\Elementor\Plugin' ) ) { \Elementor\Plugin::$instance->files_manager->clear_cache(); }
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_elementor_element_cache'" );
		flush_rewrite_rules();
		return $stats;
	}

	/** EN-Kopie einer DE-Seite (per DE-Slug). */
	protected static function en_copy_id( $de_slug ) {
		$de = get_page_by_path( $de_slug );
		if ( ! $de ) { return 0; }
		$partner = (int) get_post_meta( $de->ID, 'es_translation_of', true );
		return ( $partner && 'en' === get_post_meta( $partner, 'es_lang', true ) ) ? $partner : 0;
	}

	/** Text eines Widgets (per Elementor-ID) in einem Elementor-Baum setzen. */
	protected static function set_widget_text( &$els, $wid, $field, $value ) {
		foreach ( $els as &$el ) {
			if ( isset( $el['id'] ) && $el['id'] === $wid && isset( $el['settings'] ) ) {
				$el['settings'][ $field ] = $value;
				return true;
			}
			if ( ! empty( $el['elements'] ) && self::set_widget_text( $el['elements'], $wid, $field, $value ) ) {
				return true;
			}
		}
		return false;
	}

	protected static function set_cpt_field( $post_id, $target, $en ) {
		if ( 'content' === $target ) {
			update_post_meta( $post_id, 'es_content_en', wp_kses_post( $en ) );
			return;
		}
		if ( 0 === strpos( $target, 'lines:' ) ) {
			$key = substr( $target, 6 );
			$arr = array();
			foreach ( preg_split( '/\r?\n/', $en ) as $l ) { $l = trim( $l ); if ( $l ) { $arr[] = wp_kses_post( $l ); } }
			update_post_meta( $post_id, $key, $arr );
			return;
		}
		if ( 0 === strpos( $target, 'career:' ) ) {
			$key = substr( $target, 7 );
			$career = array();
			foreach ( preg_split( '/\r?\n/', $en ) as $l ) {
				$l = trim( $l );
				if ( ! $l ) { continue; }
				$parts = array_map( 'trim', explode( '|||', $l, 2 ) );
				$career[] = array( 'when' => sanitize_text_field( $parts[0] ), 'what' => isset( $parts[1] ) ? sanitize_text_field( $parts[1] ) : '' );
			}
			update_post_meta( $post_id, $key, $career );
			return;
		}
		update_post_meta( $post_id, $target, sanitize_text_field( $en ) );
	}

	// ---- Export: aktuelle DE/EN-Texte als Tabellenzeilen ----

	const TEXT_FIELDS = array( 'title' => 'Überschrift', 'editor' => 'Absatz', 'text' => 'Button/Text', 'button_text' => 'Button', 'eyebrow' => 'Kicker', 'caption' => 'Bildunterschrift', 'quote' => 'Zitat', 'author' => 'Zitatgeber', 'cite' => 'Quelle', 'headline' => 'Überschrift', 'item_text' => 'Listenpunkt', 'description_text' => 'Beschreibung' );

	protected static function collect_widget_texts( $els, &$out ) {
		foreach ( $els as $el ) {
			$wid = isset( $el['id'] ) ? $el['id'] : '';
			if ( isset( $el['settings'] ) && is_array( $el['settings'] ) ) {
				foreach ( self::TEXT_FIELDS as $k => $label ) {
					if ( empty( $el['settings'][ $k ] ) || ! is_string( $el['settings'][ $k ] ) ) { continue; }
					$plain = trim( wp_strip_all_tags( $el['settings'][ $k ] ) );
					if ( '' === $plain || preg_match( '#^(\[|https?://|/)#', $plain ) || ! preg_match( '/[A-Za-zÄÖÜäöüß]{2}/u', $plain ) ) { continue; }
					$out[ $wid . ':' . $k ] = array( 'kind' => $label, 'text' => trim( $el['settings'][ $k ] ) );
				}
			}
			if ( ! empty( $el['elements'] ) ) { self::collect_widget_texts( $el['elements'], $out ); }
		}
	}

	protected static function join_lines( $val, $career = false ) {
		if ( ! is_array( $val ) ) { return (string) $val; }
		$lines = array();
		foreach ( $val as $v ) {
			if ( $career && is_array( $v ) ) { $lines[] = trim( (string) ( $v['when'] ?? '' ) . ' ||| ' . (string) ( $v['what'] ?? '' ) ); }
			elseif ( is_array( $v ) ) { $lines[] = (string) ( $v['title'] ?? '' ); }
			else { $lines[] = (string) $v; }
		}
		return implode( "\n", array_filter( $lines ) );
	}

	/** Zeilen [Bereich, Feld, Deutsch, Englisch, Referenz] des aktuellen Stands. */
	public static function export_rows() {
		$rows = array( array( 'Bereich', 'Element / Feld', 'Deutsch (aktuell)', 'Englisch (bitte ausfüllen/ändern)', 'Referenz (nicht ändern)' ) );

		// Feste Seiten: alle veröffentlichten DE-Seiten mit Elementor-Inhalt
		$rows[] = array( '__section' => 'FESTE SEITEN' );
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
		foreach ( $pages as $pg ) {
			if ( 'en' === get_post_meta( $pg->ID, 'es_lang', true ) ) { continue; }
			$de_data = json_decode( (string) get_post_meta( $pg->ID, '_elementor_data', true ), true );
			if ( ! is_array( $de_data ) ) { continue; }
			$de_texts = array();
			self::collect_widget_texts( $de_data, $de_texts );
			$en_texts = array();
			$en_id = self::en_copy_id( $pg->post_name );
			if ( $en_id ) {
				$en_data = json_decode( (string) get_post_meta( $en_id, '_elementor_data', true ), true );
				if ( is_array( $en_data ) ) { self::collect_widget_texts( $en_data, $en_texts ); }
			}
			foreach ( $de_texts as $key => $t ) {
				$en_val = ( isset( $en_texts[ $key ] ) && $en_texts[ $key ]['text'] !== $t['text'] ) ? $en_texts[ $key ]['text'] : '';
				$rows[] = array( 'Seite: ' . $pg->post_title, $t['kind'], $t['text'], $en_val, 'live:' . $pg->post_name . ':' . str_replace( ':', ':', $key ) );
			}
		}

		// Inhaltstypen (News kommen als größter Block ganz ans Dateiende)
		$cpt_sources = array(
			'einzelleistung' => array( 'es_einzelleistung', array( 'Titel' => 'title', 'Untertitel' => 'meta:es_subtitle', 'Beschreibung' => 'content', 'Schwerpunkte unserer Beratung' => 'lines:es_bullets', 'Abschluss-Absatz' => 'meta:es_closing' ) ),
			'team'           => array( 'es_team', array( 'Rolle/Position' => 'meta:es_role', 'Kurzvita' => 'content', 'Erweiterte Vita' => 'meta:es_more_bio', 'Schwerpunkte' => 'lines:es_focus_areas', 'Werdegang' => 'career:es_career' ) ),
			'karriere'       => array( 'es_karriere', array( 'Titel' => 'title', 'Rollen-Kürzel' => 'meta:es_department', 'Über die Rolle' => 'content', 'Aufgaben' => 'lines:es_tasks', 'Profil' => 'lines:es_profile', 'Wir bieten' => 'lines:es_offer', 'Anstellungsart' => 'meta:es_employment_type' ) ),
			'veranstaltung'  => array( 'es_veranstaltung', array( 'Titel' => 'title', 'Beschreibung' => 'content', 'Ort' => 'meta:es_location', 'Art' => 'meta:es_kind' ) ),
			'publikation'    => array( 'es_publikation', array( 'Titel' => 'title', 'Beschreibung' => 'content', 'Kategorie' => 'meta:es_cat' ) ),
			'news'           => array( 'es_news', array( 'Titel' => 'title', 'Beitragstext' => 'content', 'Teaser' => 'excerpt' ) ),
		);
		$area_names = array( 'einzelleistung' => 'Einzelleistung', 'team' => 'Team', 'karriere' => 'Stelle', 'veranstaltung' => 'Veranstaltung', 'publikation' => 'Publikation', 'news' => 'News' );
		$section_names = array( 'einzelleistung' => 'EINZELLEISTUNGEN', 'team' => 'TEAM', 'karriere' => 'STELLENANGEBOTE', 'veranstaltung' => 'VERANSTALTUNGEN', 'publikation' => 'PUBLIKATIONEN', 'news' => 'NEWS-ARTIKEL' );
		$emit_cpt = function ( $sheet ) use ( &$rows, $cpt_sources, $area_names, $section_names ) {
			list( $pt, $fields ) = $cpt_sources[ $sheet ];
			$posts = get_posts( array( 'post_type' => $pt, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => ( 'news' === $sheet ? 'date' : 'title' ), 'order' => ( 'news' === $sheet ? 'DESC' : 'ASC' ) ) );
			$rows[] = array( '__section' => $section_names[ $sheet ] . ' (' . count( $posts ) . ')' );
			foreach ( $posts as $po ) {
				foreach ( $fields as $label => $src ) {
					if ( 'title' === $src ) { $de = $po->post_title; }
					elseif ( 'content' === $src ) { $de = trim( wp_strip_all_tags( $po->post_content ) ) ? $po->post_content : ''; }
					elseif ( 'excerpt' === $src ) { $de = (string) $po->post_excerpt; }
					elseif ( 0 === strpos( $src, 'meta:' ) ) { $de = (string) get_post_meta( $po->ID, substr( $src, 5 ), true ); }
					elseif ( 0 === strpos( $src, 'lines:' ) ) { $de = self::join_lines( get_post_meta( $po->ID, substr( $src, 6 ), true ) ); }
					else { $de = self::join_lines( get_post_meta( $po->ID, substr( $src, 7 ), true ), true ); }
					if ( '' === trim( (string) $de ) ) { continue; }
					// Vorhandene EN-Fassung über die Import-Zuordnung ermitteln
					$target = self::FIELD_MAP[ $sheet ][ $label ];
					if ( 'content' === $target ) { $en = (string) get_post_meta( $po->ID, 'es_content_en', true ); }
					elseif ( 0 === strpos( $target, 'lines:' ) ) { $en = self::join_lines( get_post_meta( $po->ID, substr( $target, 6 ), true ) ); }
					elseif ( 0 === strpos( $target, 'career:' ) ) { $en = self::join_lines( get_post_meta( $po->ID, substr( $target, 7 ), true ), true ); }
					else { $en = (string) get_post_meta( $po->ID, $target, true ); }
					$rows[] = array( $area_names[ $sheet ] . ': ' . $po->post_title, $label, $de, $en, $sheet . '.' . $po->post_name . '.' . $label );
				}
				// Aufklapp-Rubriken der Einzelleistungen: je Rubrik zwei Zeilen.
				// Inhalte gehen in der Klartext-Schreibweise raus (Leerzeile =
				// Absatz, "- " = Listenpunkt), damit der Kunde ohne
				// Formatierungs-Codes übersetzen kann.
				if ( 'einzelleistung' === $sheet ) {
					$acc    = get_post_meta( $po->ID, 'es_accordion', true );
					$acc_en = get_post_meta( $po->ID, 'es_accordion_en', true );
					if ( is_array( $acc ) ) {
						foreach ( array_values( $acc ) as $i => $arow ) {
							$n   = $i + 1;
							$ent = ( is_array( $acc_en ) && isset( $acc_en[ $i ] ) && is_array( $acc_en[ $i ] ) ) ? $acc_en[ $i ] : array();
							$rows[] = array( $area_names[ $sheet ] . ': ' . $po->post_title, 'Rubrik ' . $n . ' · Titel', (string) ( $arow['title'] ?? '' ), (string) ( $ent['title'] ?? '' ), $sheet . '.' . $po->post_name . '.Rubrik ' . $n . ' Titel' );
							$rows[] = array( $area_names[ $sheet ] . ': ' . $po->post_title, 'Rubrik ' . $n . ' · Inhalt', ESC_MetaBoxes::acc_html_to_text( (string) ( $arow['content'] ?? '' ) ), ESC_MetaBoxes::acc_html_to_text( (string) ( $ent['content'] ?? '' ) ), $sheet . '.' . $po->post_name . '.Rubrik ' . $n . ' Inhalt' );
						}
					}
				}
			}
		};
		foreach ( array( 'einzelleistung', 'team', 'karriere', 'veranstaltung', 'publikation' ) as $sheet ) {
			$emit_cpt( $sheet );
		}

		// Zentrale Einstellungen
		$rows[] = array( '__section' => 'ZENTRALE EINSTELLUNGEN' );
		foreach ( array( 'Karriere-Seiten' => array( 'esc_karriere', 'ESC_Karriere_Settings' ), 'Footer' => array( 'esc_footer', 'ESC_Footer_Settings' ) ) as $area => $cfg ) {
			list( $opt, $cls ) = $cfg;
			if ( ! class_exists( $cls ) ) { continue; }
			$opts = array_merge( $cls::defaults(), (array) get_option( $opt, array() ) );
			foreach ( $cls::en_keys() as $key ) {
				$de = isset( $opts[ $key ] ) ? (string) $opts[ $key ] : '';
				if ( '' === trim( $de ) ) { continue; }
				$en = isset( $opts[ $key . '_en' ] ) ? (string) $opts[ $key . '_en' ] : '';
				$rows[] = array( 'Einstellungen: ' . $area, $key, $de, $en, 'settings.' . $area . '.' . $key );
			}
		}

		// URL-Kürzel
		$rows[] = array( '__section' => 'URL-KÜRZEL' );
		foreach ( $pages as $pg ) {
			if ( 'en' === get_post_meta( $pg->ID, 'es_lang', true ) ) { continue; }
			$en_id = self::en_copy_id( $pg->post_name );
			if ( ! $en_id ) { continue; }
			$rows[] = array( 'URL-Kürzel', 'Seite', $pg->post_name, (string) get_post_meta( $en_id, 'es_public_slug', true ), 'url:Seite:' . $pg->post_name );
		}
		foreach ( self::URL_TYPES as $typ => $pt ) {
			foreach ( get_posts( array( 'post_type' => $pt, 'post_status' => 'publish', 'numberposts' => -1 ) ) as $po ) {
				$rows[] = array( 'URL-Kürzel', $typ, $po->post_name, (string) get_post_meta( $po->ID, 'es_slug_en', true ), 'url:' . $typ . ':' . $po->post_name );
			}
		}

		// News als größter Block ganz ans Ende
		$emit_cpt( 'news' );
		return $rows;
	}

	/**
	 * Hochgeladene XLSX-Zeilen (Spalten 0-4) in {ref, en}-Zeilen wandeln.
	 * Liefert array( 'rows' => …, 'invalid' => …, 'duplicates' => …, 'tags' => … ):
	 * "invalid" sind Zeilen mit eingetragener Übersetzung, aber fehlender/
	 * veränderter Referenz (würden sonst stillschweigend verworfen),
	 * "duplicates" doppelte Referenzen mit unterschiedlichen Übersetzungen,
	 * "tags" Zeilen, deren Übersetzung andere Formatierungs-Codes enthält
	 * als der deutsche Text daneben (vermutlich beim Übersetzen beschädigt).
	 */
	public static function rows_from_sheet( $sheet_rows ) {
		$out = array();
		$known_ref = 0;
		$invalid = array();
		$dupes = array();
		$tagwarn = array();
		$seen = array(); // ref => array( 'row' => Excel-Zeile, 'en' => Wert )
		foreach ( $sheet_rows as $cells ) {
			$rownum = isset( $cells['__r'] ) ? (int) $cells['__r'] : 0;
			$ref = isset( $cells[4] ) ? trim( (string) $cells[4] ) : '';
			$en  = isset( $cells[3] ) ? trim( (string) $cells[3] ) : '';
			// Kopf-/Leer-/Fremdzeilen anhand des Inhalts erkennen – die Position
			// im Blatt ist egal (eingefügte Zeilen, Sortierungen etc. schaden nicht)
			if ( ! preg_match( '/^(live:|settings\.|url:|einzelleistung\.|team\.|karriere\.|news\.|veranstaltung\.|publikation\.)/', $ref ) ) {
				// Gemeldet wird nur, wenn eine Übersetzung eingetragen wurde, die
				// mangels verwertbarer Referenz verloren ginge. Kopf- und
				// Abschnittszeilen sind normal und bleiben still.
				if ( '' !== $en && 'Englisch (bitte ausfüllen/ändern)' !== $en ) {
					$shown = ( mb_strlen( $ref ) > 60 ) ? mb_substr( $ref, 0, 57 ) . '…' : $ref;
					$invalid[] = 'Zeile ' . $rownum . ( '' !== $ref ? ' (Referenz „' . $shown . '")' : ' (Referenz fehlt)' );
				}
				continue;
			}
			$known_ref++;
			if ( '' === $en ) { continue; }
			if ( isset( $seen[ $ref ] ) && $seen[ $ref ]['en'] !== $en ) {
				// Beim Anwenden gewinnt die spätere Zeile (überschreibt die frühere)
				$dupes[] = 'Referenz ' . $ref . ' mehrfach mit unterschiedlichem Text (Zeile ' . $seen[ $ref ]['row'] . ' und ' . $rownum . '), übernommen wurde Zeile ' . $rownum;
			}
			$seen[ $ref ] = array( 'row' => $rownum, 'en' => $en );
			$out[] = array( 'ref' => $ref, 'en' => $en );
			// Formatierungs-Codes gegen die Deutsch-Spalte derselben Zeile prüfen
			$de = isset( $cells[2] ) ? trim( (string) $cells[2] ) : '';
			if ( '' !== $de ) {
				$note = self::tag_diff_note( $de, $en );
				if ( null !== $note ) {
					$shown = ( mb_strlen( $ref ) > 50 ) ? mb_substr( $ref, 0, 47 ) . '…' : $ref;
					$tagwarn[] = 'Zeile ' . $rownum . ' (' . $shown . '): ' . $note;
				}
			}
		}
		// Keine einzige bekannte Referenz → vermutlich falsche/umgebaute Datei
		if ( 0 === $known_ref ) {
			return new WP_Error( 'wrong_file', 'Keine gültigen Referenzen gefunden – bitte die über „Übersetzungsdatei herunterladen" erzeugte Datei verwenden (Spalte „Referenz" darf nicht verändert werden).' );
		}
		return array( 'rows' => $out, 'invalid' => $invalid, 'duplicates' => $dupes, 'tags' => $tagwarn );
	}

	/**
	 * Normalisierte Liste der Formatierungs-Codes eines Textes: Tags in
	 * Kleinschreibung, Mehrfach-Leerraum kollabiert, "<br />" wie "<br>".
	 */
	protected static function tag_list( $text ) {
		if ( ! preg_match_all( '/<[^>]+>/', (string) $text, $m ) ) { return array(); }
		$out = array();
		foreach ( $m[0] as $t ) {
			$t = strtolower( preg_replace( '/\s+/', ' ', $t ) );
			$t = preg_replace( '/\s*\/\s*>$/', '>', $t );
			$out[] = $t;
		}
		return $out;
	}

	/**
	 * Kurze Meldung, wenn die Übersetzung andere Formatierungs-Codes enthält
	 * als der deutsche Text, sonst null. Verglichen werden die Tag-Mengen:
	 * eine (legitim) geänderte Reihenfolge löst keine Warnung aus, fehlende,
	 * zusätzliche oder veränderte Tags (auch href-/class-Änderungen) schon.
	 */
	protected static function tag_diff_note( $de, $en ) {
		$a = self::tag_list( $de );
		$b = self::tag_list( $en );
		if ( $a === $b ) { return null; }
		$ca = array_count_values( $a );
		$cb = array_count_values( $b );
		$missing = array();
		$extra = array();
		foreach ( $ca as $t => $n ) {
			$d = $n - ( isset( $cb[ $t ] ) ? $cb[ $t ] : 0 );
			if ( $d > 0 ) { $missing[] = $t . ( $d > 1 ? ' (' . $d . 'x)' : '' ); }
		}
		foreach ( $cb as $t => $n ) {
			$d = $n - ( isset( $ca[ $t ] ) ? $ca[ $t ] : 0 );
			if ( $d > 0 ) { $extra[] = $t . ( $d > 1 ? ' (' . $d . 'x)' : '' ); }
		}
		if ( ! $missing && ! $extra ) { return null; }
		$shorten = function ( $t ) { return ( mb_strlen( $t ) > 40 ) ? mb_substr( $t, 0, 37 ) . '…>' : $t; };
		$parts = array();
		if ( $missing ) { $parts[] = 'fehlt ' . implode( ', ', array_map( $shorten, array_slice( $missing, 0, 5 ) ) ) . ( count( $missing ) > 5 ? ' u. a.' : '' ); }
		if ( $extra )   { $parts[] = 'zusätzlich ' . implode( ', ', array_map( $shorten, array_slice( $extra, 0, 5 ) ) ) . ( count( $extra ) > 5 ? ' u. a.' : '' ); }
		return implode( '; ', $parts );
	}
}

/** Export-Download: Übersetzungsdatei mit aktuellem DE/EN-Stand. */
add_action( 'admin_post_esc_lang_export', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Keine Berechtigung.' ); }
	check_admin_referer( 'esc_lang_export' );
	require_once ESC_DIR . 'inc/lang-xlsx.php';
	$rows = ES_Lang_Import::export_rows();
	$tmp  = wp_tempnam( 'uebersetzungen.xlsx' );
	ES_Lang_Xlsx::write( $tmp, $rows );
	header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
	header( 'Content-Disposition: attachment; filename="Uebersetzungen-Energiesozietaet-' . gmdate( 'Y-m-d' ) . '.xlsx"' );
	header( 'Content-Length: ' . filesize( $tmp ) );
	readfile( $tmp );
	unlink( $tmp );
	exit;
} );

/** Admin-Seite: Theme Options → EN-Import. */
add_action( 'admin_menu', function () {
	add_submenu_page( 'es-theme-options', 'EN-Import', 'EN-Import', 'manage_options', 'esc-lang-import', function () {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$result = null;
		if ( isset( $_POST['esc_lang_import_run'] ) && check_admin_referer( 'esc_lang_import' ) ) {
			$result = ES_Lang_Import::apply_file();
		}
		if ( isset( $_POST['esc_lang_upload_run'] ) && check_admin_referer( 'esc_lang_import' ) ) {
			if ( ! empty( $_FILES['esc_lang_file']['tmp_name'] ) ) {
				require_once ESC_DIR . 'inc/lang-xlsx.php';
				$sheet = ES_Lang_Xlsx::read( $_FILES['esc_lang_file']['tmp_name'] );
				if ( is_wp_error( $sheet ) ) {
					$result = $sheet;
				} else {
					$parsed = ES_Lang_Import::rows_from_sheet( $sheet );
					if ( is_wp_error( $parsed ) ) {
						$result = $parsed;
					} else {
						$result = ES_Lang_Import::apply_rows( $parsed['rows'] );
						if ( ! is_wp_error( $result ) ) {
							$result['invalid']    = $parsed['invalid'];
							$result['duplicates'] = $parsed['duplicates'];
							$result['tags']       = $parsed['tags'];
						}
					}
				}
			} else {
				$result = new WP_Error( 'no_upload', 'Bitte eine XLSX-Datei auswählen.' );
			}
		}
		if ( isset( $_POST['esc_lang_copies_run'] ) && check_admin_referer( 'esc_lang_import' ) ) {
			$made = ES_Lang::create_page_copies();
			echo '<div class="notice notice-success"><p>Neu angelegte EN-Seitenkopien: ' . ( $made ? esc_html( implode( ', ', $made ) ) : 'keine (alle vorhanden)' ) . '</p></div>';
		}
		if ( isset( $_POST['esc_lang_unprotect'], $_POST['esc_lang_unprotect_id'] ) && check_admin_referer( 'esc_lang_import' ) ) {
			$uid = (int) $_POST['esc_lang_unprotect_id'];
			if ( $uid && 'en' === get_post_meta( $uid, 'es_lang', true ) ) {
				delete_post_meta( $uid, 'es_translated' );
				$de_id = (int) get_post_meta( $uid, 'es_translation_of', true );
				if ( $de_id ) { ES_Lang::sync_copy_from_de( $de_id ); }
				echo '<div class="notice notice-success"><p>Übersetzungsschutz aufgehoben — die Kopie folgt wieder der deutschen Seite (und wurde soeben von ihr übernommen). Eingespielte Übersetzungen dieser Seite wurden dabei durch den deutschen Stand ersetzt.</p></div>';
			}
		}
		$file = ESC_DIR . 'data/translations-en.json';
		echo '<div class="wrap"><h1>Englische Übersetzungen</h1>';
		$copies = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => -1, 'meta_key' => 'es_lang', 'meta_value' => 'en', 'fields' => 'ids' ) );
		echo '<p><strong>Status:</strong> ' . count( $copies ) . ' englische Seitenkopien vorhanden. Zeigen englische Unterseiten „Page not found", fehlen Kopien – hier nachziehen:</p>';
		echo '<form method="post" style="margin-bottom:20px;">';
		wp_nonce_field( 'esc_lang_import' );
		submit_button( 'Fehlende EN-Seitenkopien anlegen', 'secondary', 'esc_lang_copies_run', false );
		echo '</form>';
		// Übersetzungsschutz: übersetzte Kopien folgen der DE-Seite nicht mehr —
		// hier lässt sich das pro Seite zurücksetzen.
		$protected = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => -1, 'meta_key' => 'es_translated', 'meta_value' => '1' ) );
		if ( $protected ) {
			echo '<h2>Übersetzungsschutz</h2>';
			echo '<p>Diese EN-Seiten enthalten eingespielte Übersetzungen und übernehmen deshalb keine Struktur-/Inhaltsänderungen der deutschen Seite mehr. „Schutz aufheben" setzt die Seite auf den aktuellen deutschen Stand zurück (die Übersetzungen dieser Seite gehen dabei verloren — die Übersetzungsdatei kann danach erneut hochgeladen werden).</p>';
			echo '<table class="widefat striped" style="max-width:640px;"><tbody>';
			foreach ( $protected as $pp ) {
				echo '<tr><td>' . esc_html( $pp->post_title ) . ' <code>/' . esc_html( (string) get_post_meta( $pp->ID, 'es_public_slug', true ) ) . '/</code></td><td style="text-align:right;">';
				echo '<form method="post" style="display:inline;" onsubmit="return confirm(\'Übersetzungen dieser Seite werden durch den deutschen Stand ersetzt. Fortfahren?\');">';
				wp_nonce_field( 'esc_lang_import' );
				echo '<input type="hidden" name="esc_lang_unprotect_id" value="' . (int) $pp->ID . '" />';
				submit_button( 'Schutz aufheben', 'small', 'esc_lang_unprotect', false );
				echo '</form></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '<hr>';
		echo '<h2>1 · Übersetzungsdatei exportieren</h2>';
		echo '<p>Erzeugt eine Excel-Datei mit allen aktuellen deutschen Texten und den bereits vorhandenen englischen Fassungen zum Ausfüllen. Neue Seiten und Inhalte sind automatisch enthalten.</p>';
		echo '<p><a class="button button-secondary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=esc_lang_export' ), 'esc_lang_export' ) ) . '">Übersetzungsdatei herunterladen (XLSX)</a></p>';
		echo '<h2>2 · Ausgefüllte Datei hochladen</h2>';
		echo '<p>Nur die Spalte „Englisch" und die Spalte „Referenz" werden gelesen; leere Englisch-Zellen bleiben unverändert. Fehlende EN-Seitenkopien werden automatisch angelegt.</p>';
		echo '<form method="post" enctype="multipart/form-data">';
		wp_nonce_field( 'esc_lang_import' );
		echo '<input type="file" name="esc_lang_file" accept=".xlsx" /> ';
		submit_button( 'Hochladen und einspielen', 'primary', 'esc_lang_upload_run', false );
		echo '</form><hr>';
		if ( file_exists( $file ) ) {
			echo '<h2>Alternativ: mitgelieferte Übersetzungsdatei</h2>';
			echo '<p>Spielt die im Plugin enthaltene Übersetzungsdatei ein. Bereits eingespielte Werte werden aktualisiert; deutsche Inhalte bleiben unberührt.</p>';
		}
		if ( $result ) {
			if ( is_wp_error( $result ) ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
			} else {
				echo '<div class="notice notice-success"><p>Eingespielt: ' . (int) $result['pages'] . ' Seiten-Texte, ' . (int) $result['cpt'] . ' Inhalts-Felder, ' . (int) $result['settings'] . ' Einstellungen, ' . (int) $result['slugs'] . ' URL-Kürzel.</p>';
				if ( ! empty( $result['skipped'] ) ) {
					echo '<p><strong>Übersprungen:</strong><br>' . esc_html( implode( ' · ', array_slice( $result['skipped'], 0, 20 ) ) ) . '</p>';
				}
				echo '</div>';
				// Warnungen aus der Datei-Prüfung: Übersetzungen ohne verwertbare
				// Referenz, doppelte Referenzen sowie abweichende Formatierungs-Codes.
				if ( ! empty( $result['invalid'] ) || ! empty( $result['duplicates'] ) || ! empty( $result['tags'] ) ) {
					echo '<div class="notice notice-warning">';
					if ( ! empty( $result['invalid'] ) ) {
						echo '<p><strong>Nicht zuordenbar</strong> (Übersetzung eingetragen, aber Referenz fehlt oder wurde verändert – diese Zeilen wurden NICHT übernommen):<br>'
							. esc_html( implode( ' · ', array_slice( $result['invalid'], 0, 30 ) ) )
							. ( count( $result['invalid'] ) > 30 ? '<br>… und ' . ( count( $result['invalid'] ) - 30 ) . ' weitere' : '' ) . '</p>';
					}
					if ( ! empty( $result['duplicates'] ) ) {
						echo '<p><strong>Doppelte Referenzen:</strong><br>'
							. esc_html( implode( ' · ', array_slice( $result['duplicates'], 0, 30 ) ) )
							. ( count( $result['duplicates'] ) > 30 ? '<br>… und ' . ( count( $result['duplicates'] ) - 30 ) . ' weitere' : '' ) . '</p>';
					}
					if ( ! empty( $result['tags'] ) ) {
						echo '<p><strong>Formatierungs-Codes weichen vom deutschen Text ab</strong> (die Zeilen wurden übernommen – bitte prüfen und ggf. eine korrigierte Datei erneut hochladen):<br>'
							. implode( '<br>', array_map( 'esc_html', array_slice( $result['tags'], 0, 30 ) ) )
							. ( count( $result['tags'] ) > 30 ? '<br>… und ' . ( count( $result['tags'] ) - 30 ) . ' weitere' : '' ) . '</p>';
					}
					echo '</div>';
				}
			}
		}
		if ( file_exists( $file ) ) {
			echo '<form method="post">';
			wp_nonce_field( 'esc_lang_import' );
			submit_button( 'Übersetzungen jetzt einspielen', 'primary', 'esc_lang_import_run' );
			echo '</form>';
		}
		echo '</div>';
	}, 45 );
} );
