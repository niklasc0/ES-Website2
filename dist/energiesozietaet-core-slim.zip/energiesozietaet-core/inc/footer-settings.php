<?php
/**
 * Footer-Einstellungen – generische 3 Spalten + Brand + CTA + Copyright.
 * Spalten werden im Frontend nur gerendert, wenn ihre Überschrift gesetzt
 * ist – leere Spalten werden ausgeblendet und die übrigen rücken zusammen.
 *
 * @package Energiesozietaet_Core
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class ESC_Footer_Settings {

	const OPT = 'esc_footer';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'init', array( __CLASS__, 'maybe_relativize_urls' ) );
		add_action( 'init', array( __CLASS__, 'maybe_upgrade_contact_block' ) );
	}

	/**
	 * Einmalig: Kontaktblock-Neuordnung (Kundenwunsch). Ersetzt NUR exakt die
	 * alten Standardwerte durch die neuen (Unterzeile "Recht | Steuern |
	 * Beratung", Adressen einzeilig untereinander, Mail zuletzt, Claim wieder
	 * vollständig). Individuell angepasste Werte bleiben unangetastet.
	 */
	public static function maybe_upgrade_contact_block() {
		if ( get_option( 'esc_footer_contact_block_v1' ) ) { return; }
		$opts = (array) get_option( self::OPT, array() );
		if ( $opts ) {
			$changed = false;
			$norm = function ( $s ) { return trim( str_replace( "\r", '', (string) $s ) ); };
			$old_lines = "Recht Steuern Beratung\nRoßstraße 92 | Kennedyhaus\n40476 Düsseldorf\ninfo@energiesozietaet.de\nCaffamacherreihe 8 | 20355 Hamburg\nJungbuschstraße 6 | 68159 Mannheim";
			if ( isset( $opts['col1_lines'] ) && $norm( $opts['col1_lines'] ) === $old_lines && empty( $opts['col1_sub'] ) ) {
				unset( $opts['col1_lines'] ); // neuer Default greift
				$changed = true;
			}
			if ( isset( $opts['brand_claim'] ) && 'Ergebnisse, die weitertragen.' === trim( (string) $opts['brand_claim'] ) ) {
				unset( $opts['brand_claim'] ); // neuer Default greift
				$changed = true;
			}
			if ( $changed ) { update_option( self::OPT, $opts ); }
		}
		update_option( 'esc_footer_contact_block_v1', 1 );
	}

	/**
	 * Einmalig: intern gespeicherte absolute Button-URLs (eigene Domain) in
	 * relative Pfade umschreiben – macht die Einstellungen umzugssicher.
	 */
	public static function maybe_relativize_urls() {
		if ( get_option( 'esc_footer_relative_urls_v1' ) ) { return; }
		$opts = (array) get_option( self::OPT, array() );
		$home = untrailingslashit( home_url() );
		$changed = false;
		foreach ( array( 'cta_btn1_url', 'cta_btn2_url' ) as $k ) {
			if ( ! empty( $opts[ $k ] ) && 0 === strpos( $opts[ $k ], $home . '/' ) ) {
				$opts[ $k ] = substr( $opts[ $k ], strlen( $home ) );
				$changed = true;
			}
		}
		if ( $changed ) { update_option( self::OPT, $opts ); }
		update_option( 'esc_footer_relative_urls_v1', 1 );
	}

	public static function defaults() {
		return array(
			'cta_eyebrow'     => 'Kontakt',
			'cta_title'       => 'Haben wir Ihr Interesse geweckt?',
			'cta_subtitle'    => 'Möchten Sie uns kennenlernen?',
			'cta_btn1_label'  => 'Kontakt aufnehmen',
			'cta_btn1_url'    => '/kontakt/',
			'cta_btn2_label'  => 'info@energiesozietaet.de',
			'cta_btn2_url'    => 'mailto:info@energiesozietaet.de',

			'brand_name'    => 'Energiesozietät GmbH',
			'brand_sub'     => 'Recht · Steuern · Beratung',
			'brand_claim'   => 'Beratung aus Leidenschaft - Ergebnisse, die weitertragen.',
			'badges'        => "BVÖD\nForum Contracting\nVKU",

			// Spalte 1 (Adresse) + Spalte 2 (Navigation) erscheinen im Grid;
			// Spalte 3 (Rechtliches) speist nur die zentrierte Copyright-Leiste.
			'col1_heading' => 'Energiesozietät GmbH',
			'col1_sub'     => 'Recht | Steuern | Beratung',
			'col1_lines'   => "Roßstraße 92 · Kennedyhaus · 40476 Düsseldorf\nCaffamacherreihe 8 · 20355 Hamburg\nJungbuschstraße 6 · 68159 Mannheim\ninfo@energiesozietaet.de | mailto:info@energiesozietaet.de",
			'col2_sub'     => '',
			'col3_sub'     => '',
			'col2_heading' => 'Navigation',
			'col2_lines'   => "Home | /\nPhilosophie | /philosophie/\nLeistungen | /leistungen/\nTeam | /team/\nPublikationen | /publikationen/\nKarriere | /karriere/\nNews | /news/\nVeranstaltungen | /veranstaltungen/\nKontakt | /kontakt/",
			'col3_heading' => 'Rechtliches',
			'col3_lines'   => "Impressum | /impressum/\nDatenschutz | /datenschutzerklaerung/",

			'copyright' => '© {year} Energiesozietät GmbH · Alle Rechte vorbehalten.',
		);
	}

	/** Keys mit englischer Fassung (Suffix _en). */
	public static function en_keys() {
		return array(
			'cta_eyebrow', 'cta_title', 'cta_subtitle', 'cta_btn1_label', 'cta_btn2_label',
			'brand_sub', 'brand_claim',
			'col1_heading', 'col1_sub', 'col1_lines', 'col2_heading', 'col2_sub', 'col2_lines', 'col3_heading', 'col3_sub', 'col3_lines',
			'copyright',
		);
	}

	public static function get( $key = null ) {
		$opts = (array) get_option( self::OPT, array() );
		// Backward-Compat: alte Keys (col_anschrift_*, col_kontakt_*, col_legal_*) auf neue mappen
		$legacy_map = array(
			'col_anschrift_heading' => 'col1_heading', 'col_anschrift_lines' => 'col1_lines',
			'col_kontakt_heading'   => 'col2_heading', 'col_kontakt_lines'   => 'col2_lines',
			'col_legal_heading'     => 'col3_heading', 'col_legal_lines'     => 'col3_lines',
		);
		foreach ( $legacy_map as $old => $new ) {
			if ( ! isset( $opts[ $new ] ) && isset( $opts[ $old ] ) ) {
				$opts[ $new ] = $opts[ $old ];
			}
		}
		$opts = array_merge( self::defaults(), $opts );
		if ( function_exists( 'es_is_en' ) && es_is_en() ) {
			foreach ( self::en_keys() as $k ) {
				if ( ! empty( $opts[ $k . '_en' ] ) ) { $opts[ $k ] = $opts[ $k . '_en' ]; }
			}
		}
		return $key ? ( $opts[ $key ] ?? '' ) : $opts;
	}

	public static function parse_links( $raw ) {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) $raw ) as $ln ) {
			$ln = trim( $ln );
			if ( '' === $ln ) { continue; }
			$parts = array_map( 'trim', explode( '|', $ln, 2 ) );
			$url   = $parts[1] ?? '';
			// Nur echte Ziele verlinken. Ist der Teil hinter der ersten Pipe keine
			// URL (z. B. "Recht | Steuern | Beratung"), ist die Pipe nur Text:
			// Zeile unverändert anzeigen.
			if ( $url && ! preg_match( '#^(https?://|/|\#|mailto:|tel:)#i', $url ) ) {
				$out[] = array( 'label' => $ln, 'url' => '' );
				continue;
			}
			$out[] = array( 'label' => $parts[0], 'url' => $url );
		}
		return $out;
	}

	public static function parse_lines( $raw ) {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) $raw ) as $ln ) {
			$ln = trim( $ln );
			if ( '' !== $ln ) { $out[] = $ln; }
		}
		return $out;
	}

	public static function register() {
		register_setting( 'esc_footer_group', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $input ) {
		$defaults = self::defaults();
		$out = array();
		foreach ( $defaults as $k => $v ) {
			if ( ! isset( $input[ $k ] ) ) { $out[ $k ] = $v; continue; }
			$val = wp_unslash( $input[ $k ] );
			if ( in_array( $k, array( 'cta_btn1_url', 'cta_btn2_url' ), true ) ) {
				$out[ $k ] = esc_url_raw( $val );
			} elseif ( false !== strpos( $k, '_lines' ) || 'badges' === $k || in_array( $k, array( 'cta_subtitle', 'brand_claim' ), true ) ) {
				$out[ $k ] = wp_kses_post( $val );
			} else {
				$out[ $k ] = sanitize_text_field( $val );
			}
		}
		foreach ( self::en_keys() as $k ) {
			$key_en = $k . '_en';
			if ( ! isset( $input[ $key_en ] ) ) { $out[ $key_en ] = ''; continue; }
			$val = wp_unslash( $input[ $key_en ] );
			$out[ $key_en ] = ( false !== strpos( $k, '_lines' ) || in_array( $k, array( 'cta_subtitle', 'brand_claim' ), true ) )
				? wp_kses_post( $val )
				: sanitize_text_field( $val );
		}
		return $out;
	}

	public static function menu() {
		add_submenu_page( 'es-theme-options', 'Footer', 'Footer', 'manage_options', 'esc-footer', array( __CLASS__, 'render' ), 40 );
	}

	protected static function raw_val( $name ) {
		$opts = (array) get_option( self::OPT, array() );
		$opts = array_merge( self::defaults(), $opts );
		return isset( $opts[ $name ] ) ? $opts[ $name ] : '';
	}

	protected static function input( $name, $label, $hint = '' ) {
		$val = self::raw_val( $name );
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th><td>';
		if ( in_array( $name, self::en_keys(), true ) ) {
			$val_en = self::raw_val( $name . '_en' );
			echo '<div style="display:flex;gap:16px;flex-wrap:wrap;max-width:980px;">';
			echo '<div style="flex:1;min-width:280px;"><input type="text" name="' . esc_attr( self::OPT . '[' . $name . ']' ) . '" value="' . esc_attr( $val ) . '" style="width:100%;" />';
			echo '<p class="description" style="font-style:normal;margin:2px 0 0;">Deutsch</p></div>';
			echo '<div style="flex:1;min-width:280px;"><input type="text" name="' . esc_attr( self::OPT . '[' . $name . '_en]' ) . '" value="' . esc_attr( $val_en ) . '" style="width:100%;" placeholder="EN" />';
			echo '<p class="description" style="font-style:normal;margin:2px 0 0;">Englisch – leer = deutsche Fassung</p></div>';
			echo '</div>';
		} else {
			echo '<input type="text" name="' . esc_attr( self::OPT . '[' . $name . ']' ) . '" value="' . esc_attr( $val ) . '" style="width:100%;max-width:640px;" />';
		}
		if ( $hint ) { echo '<p class="description" style="font-style:normal;">' . wp_kses_post( $hint ) . '</p>'; }
		echo '</td></tr>';
	}

	protected static function textarea( $name, $label, $hint = '', $rows = 4 ) {
		$val = self::raw_val( $name );
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th><td>';
		if ( in_array( $name, self::en_keys(), true ) ) {
			$val_en = self::raw_val( $name . '_en' );
			echo '<div style="display:flex;gap:16px;flex-wrap:wrap;max-width:980px;">';
			echo '<div style="flex:1;min-width:280px;"><textarea name="' . esc_attr( self::OPT . '[' . $name . ']' ) . '" rows="' . (int) $rows . '" style="width:100%;">' . esc_textarea( $val ) . '</textarea>';
			echo '<p class="description" style="font-style:normal;margin:2px 0 0;">Deutsch</p></div>';
			echo '<div style="flex:1;min-width:280px;"><textarea name="' . esc_attr( self::OPT . '[' . $name . '_en]' ) . '" rows="' . (int) $rows . '" style="width:100%;" placeholder="EN">' . esc_textarea( $val_en ) . '</textarea>';
			echo '<p class="description" style="font-style:normal;margin:2px 0 0;">Englisch – leer = deutsche Fassung</p></div>';
			echo '</div>';
		} else {
			echo '<textarea name="' . esc_attr( self::OPT . '[' . $name . ']' ) . '" rows="' . (int) $rows . '" style="width:100%;max-width:640px;">' . esc_textarea( $val ) . '</textarea>';
		}
		if ( $hint ) { echo '<p class="description" style="font-style:normal;">' . wp_kses_post( $hint ) . '</p>'; }
		echo '</td></tr>';
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		?>
		<div class="wrap">
			<h1>Footer</h1>
			<p>Alle Inhalte des Seiten-Footers zentral pflegen. <strong>Spalten ohne Überschrift werden ausgeblendet</strong> – die übrigen rücken automatisch zusammen.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'esc_footer_group' ); ?>

				<h2>CTA-Bar (oberhalb des Footers)</h2>
				<table class="form-table"><tbody>
					<?php
					self::input( 'cta_eyebrow',    'Eyebrow' );
					self::input( 'cta_title',      'Überschrift' );
					self::input( 'cta_subtitle',   'Untertitel', 'HTML erlaubt' );
					self::input( 'cta_btn1_label', 'Button 1 · Text' );
					self::input( 'cta_btn1_url',   'Button 1 · URL' );
					self::input( 'cta_btn2_label', 'Button 2 · Text' );
					self::input( 'cta_btn2_url',   'Button 2 · URL' );
					?>
				</tbody></table>

				<h2>Brand-Spalte (links)</h2>
				<table class="form-table"><tbody>
					<?php
					self::input(    'brand_name',  'Name' );
					self::input(    'brand_sub',   'Untertitel / Tagline' );
					self::textarea( 'brand_claim', 'Claim', '1–2 Sätze.', 2 );
					self::textarea( 'badges',      'Badges / Mitgliedschaften', 'Eine Zeile pro Badge.', 4 );
					?>
				</tbody></table>

				<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
					<h2>Spalte <?php echo (int) $i; ?></h2>
					<p style="color:#5A6577;">Lasse die Überschrift leer, um diese Spalte komplett auszublenden.</p>
					<table class="form-table"><tbody>
						<?php
						self::input(    "col{$i}_heading", 'Überschrift' );
						self::input(    "col{$i}_sub",     'Unterzeile (optional)', 'Erscheint abgesetzt direkt unter der Überschrift, z. B. <code>Recht | Steuern | Beratung</code>.' );
						self::textarea( "col{$i}_lines",   'Zeilen · Format „Label | URL"', 'Eine Zeile pro Eintrag – Format <code>Text | URL</code>. URL optional.', 5 );
						?>
					</tbody></table>
				<?php endfor; ?>

				<h2>Copyright-Zeile</h2>
				<table class="form-table"><tbody>
					<?php self::input( 'copyright', 'Text', 'Platzhalter <code>{year}</code> wird automatisch ersetzt.' ); ?>
				</tbody></table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
ESC_Footer_Settings::init();
